import { E as sanitize_props, F as rest_props, A as push, G as fallback, B as setContext, P as spread_props, M as slot, O as bind_props, C as pop, S as getContext, T as element, N as attr_class, W as attr, K as clsx, J as spread_attributes, U as escape_html, X as invalid_default_snippet, Y as sanitize_slots, Z as ensure_array_like, _ as maybe_selected, $ as stringify, a0 as copy_payload, a1 as assign_payload } from "../../../chunks/index.js";
import "clsx";
import { F as Frame } from "../../../chunks/Frame.js";
import { twMerge } from "tailwind-merge";
import { w as writable } from "../../../chunks/index2.js";
function Accordion($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "multiple",
    "flush",
    "activeClass",
    "inactiveClass",
    "defaultClass",
    "classActive",
    "classInactive"
  ]);
  push();
  let multiple = fallback($$props["multiple"], false);
  let flush = fallback($$props["flush"], false);
  let activeClass = fallback($$props["activeClass"], "bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800");
  let inactiveClass = fallback($$props["inactiveClass"], "text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800");
  let defaultClass = fallback($$props["defaultClass"], "text-gray-500 dark:text-gray-400");
  let classActive = fallback($$props["classActive"], "");
  let classInactive = fallback($$props["classInactive"], "");
  const ctx = {
    flush,
    activeClass: twMerge(activeClass, classActive),
    inactiveClass: twMerge(inactiveClass, classInactive),
    selected: multiple ? void 0 : writable()
  };
  setContext("ctx", ctx);
  let frameClass;
  frameClass = twMerge(defaultClass, $$sanitized_props.class);
  Frame($$payload, spread_props([
    $$restProps,
    {
      class: frameClass,
      color: "none",
      children: ($$payload2) => {
        $$payload2.out += `<!---->`;
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
  bind_props($$props, {
    multiple,
    flush,
    activeClass,
    inactiveClass,
    defaultClass,
    classActive,
    classInactive
  });
  pop();
}
function AccordionItem($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  push();
  let contentClass;
  let tag = fallback($$props["tag"], "h2");
  let open = fallback($$props["open"], false);
  let activeClass = fallback($$props["activeClass"], () => void 0, true);
  let inactiveClass = fallback($$props["inactiveClass"], () => void 0, true);
  let defaultClass = fallback($$props["defaultClass"], "flex items-center justify-between w-full font-medium text-left group-first:rounded-t-xl border-gray-200 dark:border-gray-700");
  let transitionType = fallback($$props["transitionType"], "slide");
  let transitionParams = fallback($$props["transitionParams"], () => ({}), true);
  let paddingFlush = fallback($$props["paddingFlush"], "py-5");
  let paddingDefault = fallback($$props["paddingDefault"], "p-5");
  let textFlushOpen = fallback($$props["textFlushOpen"], "text-gray-900 dark:text-white");
  let textFlushDefault = fallback($$props["textFlushDefault"], "text-gray-500 dark:text-gray-400");
  let borderClass = fallback($$props["borderClass"], "border-s border-e group-first:border-t");
  let borderOpenClass = fallback($$props["borderOpenClass"], "border-s border-e");
  let borderBottomClass = fallback($$props["borderBottomClass"], "border-b");
  let borderSharedClass = fallback($$props["borderSharedClass"], "border-gray-200 dark:border-gray-700");
  let classActive = fallback($$props["classActive"], () => void 0, true);
  let classInactive = fallback($$props["classInactive"], () => void 0, true);
  let activeCls = twMerge(activeClass, classActive);
  let inactiveCls = twMerge(inactiveClass, classInactive);
  const ctx = getContext("ctx") ?? {};
  ctx.selected ?? writable();
  open = false;
  let buttonClass;
  buttonClass = twMerge([
    defaultClass,
    ctx.flush || borderClass,
    borderBottomClass,
    borderSharedClass,
    ctx.flush ? paddingFlush : paddingDefault,
    open && (ctx.flush ? textFlushOpen : activeCls || ctx.activeClass),
    !open && (ctx.flush ? textFlushDefault : inactiveCls || ctx.inactiveClass),
    $$sanitized_props.class
  ]);
  contentClass = twMerge([
    ctx.flush ? paddingFlush : paddingDefault,
    ctx.flush ? "" : borderOpenClass,
    borderBottomClass,
    borderSharedClass
  ]);
  element(
    $$payload,
    tag,
    () => {
      $$payload.out += ` class="group"`;
    },
    () => {
      $$payload.out += `<button type="button"${attr_class(clsx(buttonClass))}${attr("aria-expanded", open)}><!---->`;
      slot($$payload, $$props, "header", {}, null);
      $$payload.out += `<!----> `;
      if (open) {
        $$payload.out += "<!--[-->";
        $$payload.out += `<!---->`;
        slot($$payload, $$props, "arrowup", {}, () => {
          $$payload.out += `<svg class="w-3 h-3 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5 5 1 1 5"></path></svg>`;
        });
        $$payload.out += `<!---->`;
      } else {
        $$payload.out += "<!--[!-->";
        $$payload.out += `<!---->`;
        slot($$payload, $$props, "arrowdown", {}, () => {
          $$payload.out += `<svg class="w-3 h-3 text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6"><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"></path></svg>`;
        });
        $$payload.out += `<!---->`;
      }
      $$payload.out += `<!--]--></button>`;
    }
  );
  $$payload.out += ` `;
  if (open) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div><div${attr_class(clsx(contentClass))}><!---->`;
    slot($$payload, $$props, "default", {}, null);
    $$payload.out += `<!----></div></div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, {
    tag,
    open,
    activeClass,
    inactiveClass,
    defaultClass,
    transitionType,
    transitionParams,
    paddingFlush,
    paddingDefault,
    textFlushOpen,
    textFlushDefault,
    borderClass,
    borderOpenClass,
    borderBottomClass,
    borderSharedClass,
    classActive,
    classInactive
  });
  pop();
}
function ToolbarButton($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "color",
    "name",
    "ariaLabel",
    "size",
    "href"
  ]);
  push();
  let color = fallback($$props["color"], "default");
  let name = fallback($$props["name"], () => void 0, true);
  let ariaLabel = fallback($$props["ariaLabel"], () => void 0, true);
  let size = fallback($$props["size"], "md");
  let href = fallback($$props["href"], () => void 0, true);
  const background = getContext("background");
  const colors = {
    dark: "text-gray-500 hover:text-gray-900 hover:bg-gray-200 dark:text-gray-400 dark:hover:text-white dark:hover:bg-gray-600",
    gray: "text-gray-500 focus:ring-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 dark:hover:text-gray-300",
    red: "text-red-500 focus:ring-red-400 hover:bg-red-200 dark:hover:bg-red-800 dark:hover:text-red-300",
    yellow: "text-yellow-500 focus:ring-yellow-400 hover:bg-yellow-200 dark:hover:bg-yellow-800 dark:hover:text-yellow-300",
    green: "text-green-500 focus:ring-green-400 hover:bg-green-200 dark:hover:bg-green-800 dark:hover:text-green-300",
    indigo: "text-indigo-500 focus:ring-indigo-400 hover:bg-indigo-200 dark:hover:bg-indigo-800 dark:hover:text-indigo-300",
    purple: "text-purple-500 focus:ring-purple-400 hover:bg-purple-200 dark:hover:bg-purple-800 dark:hover:text-purple-300",
    pink: "text-pink-500 focus:ring-pink-400 hover:bg-pink-200 dark:hover:bg-pink-800 dark:hover:text-pink-300",
    blue: "text-blue-500 focus:ring-blue-400 hover:bg-blue-200 dark:hover:bg-blue-800 dark:hover:text-blue-300",
    primary: "text-primary-500 focus:ring-primary-400 hover:bg-primary-200 dark:hover:bg-primary-800 dark:hover:text-primary-300",
    default: "focus:ring-gray-400 hover:bg-gray-100"
  };
  const sizing = {
    xs: "m-0.5 rounded-xs focus:ring-1 p-0.5",
    sm: "m-0.5 rounded-sm focus:ring-1 p-0.5",
    md: "m-0.5 rounded-lg focus:ring-2 p-1.5",
    lg: "m-0.5 rounded-lg focus:ring-2 p-2.5"
  };
  let buttonClass;
  const svgSizes = {
    xs: "w-3 h-3",
    sm: "w-3.5 h-3.5",
    md: "w-5 h-5",
    lg: "w-5 h-5"
  };
  buttonClass = twMerge("focus:outline-hidden whitespace-normal", sizing[size], colors[color], color === "default" && (background ? "dark:hover:bg-gray-600" : "dark:hover:bg-gray-700"), $$sanitized_props.class);
  if (href) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<a${spread_attributes(
      {
        href,
        ...$$restProps,
        class: clsx(buttonClass),
        "aria-label": ariaLabel ?? name
      },
      null
    )}>`;
    if (name) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<span class="sr-only">${escape_html(name)}</span>`;
    } else {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]--> <!---->`;
    slot($$payload, $$props, "default", { svgSize: svgSizes[size] }, null);
    $$payload.out += `<!----></a>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<button${spread_attributes(
      {
        type: "button",
        ...$$restProps,
        class: clsx(buttonClass),
        "aria-label": ariaLabel ?? name
      },
      null
    )}>`;
    if (name) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<span class="sr-only">${escape_html(name)}</span>`;
    } else {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]--> <!---->`;
    slot($$payload, $$props, "default", { svgSize: svgSizes[size] }, null);
    $$payload.out += `<!----></button>`;
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { color, name, ariaLabel, size, href });
  pop();
}
function CloseButton($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["name"]);
  push();
  let name = fallback($$props["name"], "Close");
  ToolbarButton($$payload, spread_props([
    { name },
    $$restProps,
    {
      class: twMerge("ms-auto", $$sanitized_props.class),
      children: invalid_default_snippet,
      $$slots: {
        default: ($$payload2, { svgSize }) => {
          $$payload2.out += `<svg${attr_class(clsx(svgSize))} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>`;
        }
      }
    }
  ]));
  bind_props($$props, { name });
  pop();
}
function Button($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "pill",
    "outline",
    "size",
    "href",
    "type",
    "color",
    "shadow",
    "tag",
    "checked",
    "disabled"
  ]);
  push();
  const group = getContext("group");
  let pill = fallback($$props["pill"], false);
  let outline = fallback($$props["outline"], false);
  let size = fallback($$props["size"], group ? "sm" : "md");
  let href = fallback($$props["href"], () => void 0, true);
  let type = fallback($$props["type"], "button");
  let color = fallback($$props["color"], group ? outline ? "dark" : "alternative" : "primary");
  let shadow = fallback($$props["shadow"], false);
  let tag = fallback($$props["tag"], "button");
  let checked = fallback($$props["checked"], () => void 0, true);
  let disabled = fallback($$props["disabled"], false);
  const colorClasses2 = {
    alternative: "text-gray-900 bg-white border border-gray-200 hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-400 hover:text-primary-700 focus-within:text-primary-700 dark:focus-within:text-white dark:hover:text-white dark:hover:bg-gray-700",
    blue: "text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-700",
    dark: "text-white bg-gray-800 hover:bg-gray-900 dark:bg-gray-800 dark:hover:bg-gray-700",
    green: "text-white bg-green-700 hover:bg-green-800 dark:bg-green-600 dark:hover:bg-green-700",
    light: "text-gray-900 bg-white border border-gray-300 hover:bg-gray-100 dark:bg-gray-800 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600",
    primary: "text-white bg-primary-700 hover:bg-primary-800 dark:bg-primary-600 dark:hover:bg-primary-700",
    purple: "text-white bg-purple-700 hover:bg-purple-800 dark:bg-purple-600 dark:hover:bg-purple-700",
    red: "text-white bg-red-700 hover:bg-red-800 dark:bg-red-600 dark:hover:bg-red-700",
    yellow: "text-white bg-yellow-400 hover:bg-yellow-500 ",
    none: ""
  };
  const colorCheckedClasses = {
    alternative: "text-primary-700 border dark:text-primary-500 bg-gray-100 dark:bg-gray-700 border-gray-300 shadow-gray-300 dark:shadow-gray-800 shadow-inner",
    blue: "text-blue-900 bg-blue-400 dark:bg-blue-500 shadow-blue-700 dark:shadow-blue-800 shadow-inner",
    dark: "text-white bg-gray-500 dark:bg-gray-600 shadow-gray-800 dark:shadow-gray-900 shadow-inner",
    green: "text-green-900 bg-green-400 dark:bg-green-500 shadow-green-700 dark:shadow-green-800 shadow-inner",
    light: "text-gray-900 bg-gray-100 border border-gray-300 dark:bg-gray-500 dark:text-gray-900 dark:border-gray-700 shadow-gray-300 dark:shadow-gray-700 shadow-inner",
    primary: "text-primary-900 bg-primary-400 dark:bg-primary-500 shadow-primary-700 dark:shadow-primary-800 shadow-inner",
    purple: "text-purple-900 bg-purple-400 dark:bg-purple-500 shadow-purple-700 dark:shadow-purple-800 shadow-inner",
    red: "text-red-900 bg-red-400 dark:bg-red-500 shadow-red-700 dark:shadow-red-800 shadow-inner",
    yellow: "text-yellow-900 bg-yellow-300 dark:bg-yellow-400 shadow-yellow-500 dark:shadow-yellow-700 shadow-inner",
    none: ""
  };
  const coloredFocusClasses = {
    alternative: "focus-within:ring-gray-200 dark:focus-within:ring-gray-700",
    blue: "focus-within:ring-blue-300 dark:focus-within:ring-blue-800",
    dark: "focus-within:ring-gray-300 dark:focus-within:ring-gray-700",
    green: "focus-within:ring-green-300 dark:focus-within:ring-green-800",
    light: "focus-within:ring-gray-200 dark:focus-within:ring-gray-700",
    primary: "focus-within:ring-primary-300 dark:focus-within:ring-primary-800",
    purple: "focus-within:ring-purple-300 dark:focus-within:ring-purple-900",
    red: "focus-within:ring-red-300 dark:focus-within:ring-red-900",
    yellow: "focus-within:ring-yellow-300 dark:focus-within:ring-yellow-900",
    none: ""
  };
  const coloredShadowClasses = {
    alternative: "shadow-gray-500/50 dark:shadow-gray-800/80",
    blue: "shadow-blue-500/50 dark:shadow-blue-800/80",
    dark: "shadow-gray-500/50 dark:shadow-gray-800/80",
    green: "shadow-green-500/50 dark:shadow-green-800/80",
    light: "shadow-gray-500/50 dark:shadow-gray-800/80",
    primary: "shadow-primary-500/50 dark:shadow-primary-800/80",
    purple: "shadow-purple-500/50 dark:shadow-purple-800/80",
    red: "shadow-red-500/50 dark:shadow-red-800/80 ",
    yellow: "shadow-yellow-500/50 dark:shadow-yellow-800/80 ",
    none: ""
  };
  const outlineClasses = {
    alternative: "text-gray-900 dark:text-gray-400 hover:text-white border border-gray-800 hover:bg-gray-900 focus-within:bg-gray-900 focus-within:text-white focus-within:ring-gray-300 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-600 dark:focus-within:ring-gray-800",
    blue: "text-blue-700 hover:text-white border border-blue-700 hover:bg-blue-800 dark:border-blue-500 dark:text-blue-500 dark:hover:text-white dark:hover:bg-blue-600",
    dark: "text-gray-900 hover:text-white border border-gray-800 hover:bg-gray-900 focus-within:bg-gray-900 focus-within:text-white dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-600",
    green: "text-green-700 hover:text-white border border-green-700 hover:bg-green-800 dark:border-green-500 dark:text-green-500 dark:hover:text-white dark:hover:bg-green-600",
    light: "text-gray-500 hover:text-gray-900 bg-white border border-gray-200 dark:border-gray-600 dark:hover:text-white dark:text-gray-400 hover:bg-gray-50 dark:bg-gray-700 dark:hover:bg-gray-600",
    primary: "text-primary-700 hover:text-white border border-primary-700 hover:bg-primary-700 dark:border-primary-500 dark:text-primary-500 dark:hover:text-white dark:hover:bg-primary-600",
    purple: "text-purple-700 hover:text-white border border-purple-700 hover:bg-purple-800 dark:border-purple-400 dark:text-purple-400 dark:hover:text-white dark:hover:bg-purple-500",
    red: "text-red-700 hover:text-white border border-red-700 hover:bg-red-800 dark:border-red-500 dark:text-red-500 dark:hover:text-white dark:hover:bg-red-600",
    yellow: "text-yellow-400 hover:text-white border border-yellow-400 hover:bg-yellow-500 dark:border-yellow-300 dark:text-yellow-300 dark:hover:text-white dark:hover:bg-yellow-400",
    none: ""
  };
  const sizeClasses = {
    xs: "px-3 py-2 text-xs",
    sm: "px-4 py-2 text-sm",
    md: "px-5 py-2.5 text-sm",
    lg: "px-5 py-3 text-base",
    xl: "px-6 py-3.5 text-base"
  };
  const hasBorder = () => outline || color === "alternative" || color === "light";
  let buttonClass;
  buttonClass = twMerge("text-center font-medium", group ? "focus-within:ring-2" : "focus-within:ring-4", group && "focus-within:z-10", group || "focus-within:outline-hidden", "inline-flex items-center justify-center " + sizeClasses[size], outline && checked && "border dark:border-gray-900", outline && checked && colorCheckedClasses[color], outline && !checked && outlineClasses[color], !outline && checked && colorCheckedClasses[color], !outline && !checked && colorClasses2[color], color === "alternative" && (group && !checked ? "dark:bg-gray-700 dark:text-white dark:border-gray-700 dark:hover:border-gray-600 dark:hover:bg-gray-600" : "dark:bg-transparent dark:border-gray-600 dark:hover:border-gray-600"), outline && color === "dark" && (group ? checked ? "bg-gray-900 border-gray-800 dark:border-white dark:bg-gray-600" : "dark:text-white border-gray-800 dark:border-white" : "dark:text-gray-400 dark:border-gray-700"), coloredFocusClasses[color], hasBorder() && group && "not-first:-ms-px", group ? pill && "first:rounded-s-full last:rounded-e-full" || "first:rounded-s-lg last:rounded-e-lg" : pill && "rounded-full" || "rounded-lg", shadow && "shadow-lg", shadow && coloredShadowClasses[color], disabled && "cursor-not-allowed opacity-50", $$sanitized_props.class);
  if (href && !disabled) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<a${spread_attributes(
      {
        href,
        ...$$restProps,
        class: clsx(buttonClass),
        role: "button"
      },
      null
    )}><!---->`;
    slot($$payload, $$props, "default", {}, null);
    $$payload.out += `<!----></a>`;
  } else if (tag === "label") {
    $$payload.out += "<!--[1-->";
    $$payload.out += `<label${spread_attributes(
      {
        ...$$restProps,
        class: clsx(buttonClass)
      },
      null
    )}><!---->`;
    slot($$payload, $$props, "default", {}, null);
    $$payload.out += `<!----></label>`;
  } else if (tag === "button") {
    $$payload.out += "<!--[2-->";
    $$payload.out += `<button${spread_attributes(
      {
        type,
        ...$$restProps,
        disabled,
        class: clsx(buttonClass)
      },
      null
    )}><!---->`;
    slot($$payload, $$props, "default", {}, null);
    $$payload.out += `<!----></button>`;
  } else {
    $$payload.out += "<!--[!-->";
    element(
      $$payload,
      tag,
      () => {
        $$payload.out += `${spread_attributes(
          {
            ...$$restProps,
            class: clsx(buttonClass)
          },
          null
        )}`;
      },
      () => {
        $$payload.out += `<!---->`;
        slot($$payload, $$props, "default", {}, null);
        $$payload.out += `<!---->`;
      }
    );
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, {
    pill,
    outline,
    size,
    href,
    type,
    color,
    shadow,
    tag,
    checked,
    disabled
  });
  pop();
}
function ButtonGroup($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["size", "divClass"]);
  push();
  let size = fallback($$props["size"], "md");
  let divClass = fallback($$props["divClass"], "inline-flex rounded-lg shadow-xs");
  setContext("group", { size });
  $$payload.out += `<div${spread_attributes(
    {
      ...$$restProps,
      class: clsx(twMerge(divClass, $$sanitized_props.class)),
      role: "group"
    },
    null
  )}><!---->`;
  slot($$payload, $$props, "default", {}, null);
  $$payload.out += `<!----></div>`;
  bind_props($$props, { size, divClass });
  pop();
}
function Label($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, ["color", "defaultClass", "show"]);
  push();
  let labelClass2;
  let color = fallback($$props["color"], "gray");
  let defaultClass = fallback($$props["defaultClass"], "text-sm rtl:text-right font-medium block");
  let show = fallback($$props["show"], true);
  const colorClasses2 = {
    gray: "text-gray-900 dark:text-gray-300",
    green: "text-green-700 dark:text-green-500",
    red: "text-red-700 dark:text-red-500",
    disabled: "text-gray-400 dark:text-gray-500 grayscale contrast-50"
  };
  {
    color = color;
  }
  labelClass2 = twMerge(defaultClass, colorClasses2[color], $$sanitized_props.class);
  if (show) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<label${spread_attributes({ ...$$restProps, class: clsx(labelClass2) }, null)}><!---->`;
    slot($$payload, $$props, "default", {}, null);
    $$payload.out += `<!----></label>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<!---->`;
    slot($$payload, $$props, "default", {}, null);
    $$payload.out += `<!---->`;
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { color, defaultClass, show });
  pop();
}
const colorClasses = {
  primary: "text-primary-600 focus:ring-primary-500 dark:focus:ring-primary-600",
  secondary: "text-secondary-600 focus:ring-secondary-500 dark:focus:ring-secondary-600",
  red: "text-red-600 focus:ring-red-500 dark:focus:ring-red-600",
  green: "text-green-600 focus:ring-green-500 dark:focus:ring-green-600",
  purple: "text-purple-600 focus:ring-purple-500 dark:focus:ring-purple-600",
  teal: "text-teal-600 focus:ring-teal-500 dark:focus:ring-teal-600",
  yellow: "text-yellow-400 focus:ring-yellow-500 dark:focus:ring-yellow-600",
  orange: "text-orange-500 focus:ring-orange-500 dark:focus:ring-orange-600",
  blue: "text-blue-600 focus:ring-blue-500 dark:focus:ring-blue-600"
};
const labelClass = (inline, extraClass) => twMerge(inline ? "inline-flex" : "flex", "items-center", extraClass);
const inputClass = (custom, color, rounded, tinted, spacing, extraClass) => twMerge("w-4 h-4 bg-gray-100 border-gray-300 dark:ring-offset-gray-800 focus:ring-2", spacing, tinted ? "dark:bg-gray-600 dark:border-gray-500" : "dark:bg-gray-700 dark:border-gray-600", custom && "sr-only peer", "rounded", colorClasses[color], extraClass);
function Checkbox($$payload, $$props) {
  const $$slots = sanitize_slots($$props);
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "color",
    "custom",
    "inline",
    "group",
    "choices",
    "value",
    "checked",
    "spacing",
    "groupLabelClass",
    "groupInputClass"
  ]);
  push();
  let color = fallback($$props["color"], "primary");
  let custom = fallback($$props["custom"], false);
  let inline = fallback($$props["inline"], false);
  let group = fallback($$props["group"], () => [], true);
  let choices = fallback($$props["choices"], () => [], true);
  let value = fallback($$props["value"], "on");
  let checked = fallback($$props["checked"], () => void 0, true);
  let spacing = fallback($$props["spacing"], () => $$slots.default ? "me-2" : "", true);
  let groupLabelClass = fallback($$props["groupLabelClass"], "");
  let groupInputClass = fallback($$props["groupInputClass"], "");
  let background = getContext("background");
  if (choices.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(choices);
    $$payload.out += `<!--[-->`;
    for (let i = 0, $$length = each_array.length; i < $$length; i++) {
      let { value: value2, label } = each_array[i];
      Label($$payload, {
        class: labelClass(inline, groupLabelClass),
        show: $$slots.default,
        for: `checkbox-${i}`,
        children: ($$payload2) => {
          $$payload2.out += `<!---->${escape_html(label)} <input${spread_attributes(
            {
              id: `checkbox-${i}`,
              type: "checkbox",
              value: value2,
              checked: group.includes(value2),
              ...$$restProps,
              class: clsx(inputClass(custom, color, true, background, spacing, groupInputClass))
            },
            null
          )}/> <!---->`;
          slot($$payload2, $$props, "default", {}, null);
          $$payload2.out += `<!---->`;
        },
        $$slots: { default: true }
      });
    }
    $$payload.out += `<!--]-->`;
  } else {
    $$payload.out += "<!--[!-->";
    Label($$payload, {
      class: labelClass(inline, $$sanitized_props.class),
      show: $$slots.default,
      children: ($$payload2) => {
        $$payload2.out += `<input${spread_attributes(
          {
            type: "checkbox",
            checked,
            value,
            ...$$restProps,
            class: clsx(inputClass(custom, color, true, background, spacing, $$slots.default || $$sanitized_props.class))
          },
          null
        )}/> <!---->`;
        slot($$payload2, $$props, "default", {}, null);
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    });
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, {
    color,
    custom,
    inline,
    group,
    choices,
    value,
    checked,
    spacing,
    groupLabelClass,
    groupInputClass
  });
  pop();
}
function Select($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "items",
    "value",
    "placeholder",
    "underline",
    "size",
    "defaultClass",
    "underlineClass"
  ]);
  push();
  let items = fallback($$props["items"], () => [], true);
  let value = fallback($$props["value"], "");
  let placeholder = fallback($$props["placeholder"], "Choose option ...");
  let underline = fallback($$props["underline"], false);
  let size = fallback($$props["size"], "md");
  let defaultClass = fallback($$props["defaultClass"], "text-gray-900 disabled:text-gray-400 bg-gray-50 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:disabled:text-gray-500 dark:focus:ring-primary-500 dark:focus:border-primary-500");
  let underlineClass = fallback($$props["underlineClass"], "text-gray-500 disabled:text-gray-400 bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:disabled:text-gray-500 dark:border-gray-700 focus:outline-hidden focus:ring-0 focus:border-gray-200 peer");
  const common = "block w-full";
  const sizes = {
    sm: "text-sm p-2",
    md: "text-sm p-2.5",
    lg: "text-base py-3 px-4"
  };
  let selectClass;
  selectClass = twMerge(common, underline ? underlineClass : defaultClass, sizes[size], underline && "px-0!", $$sanitized_props.class);
  $$payload.out += `<select${spread_attributes(
    {
      ...$$restProps,
      class: clsx(selectClass)
    },
    null
  )}>`;
  $$payload.select_value = { ...$$restProps, value }?.value;
  if (placeholder) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<option disabled${attr("selected", value === void 0 ? true : void 0, true)} value=""${maybe_selected($$payload, "")}>${escape_html(placeholder)}</option>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  if (items && items.length > 0) {
    $$payload.out += "<!--[-->";
    const each_array = ensure_array_like(items);
    $$payload.out += `<!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let { value: itemValue, name, disabled } = each_array[$$index];
      $$payload.out += `<option${attr("disabled", disabled, true)}${attr("value", itemValue)}${maybe_selected($$payload, itemValue)}${attr("selected", itemValue === value ? true : void 0, true)}>${escape_html(name)}</option>`;
    }
    $$payload.out += `<!--]-->`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<!---->`;
    slot($$payload, $$props, "default", {}, null);
    $$payload.out += `<!---->`;
  }
  $$payload.out += `<!--]-->`;
  $$payload.select_value = void 0;
  $$payload.out += `</select>`;
  bind_props($$props, {
    items,
    value,
    placeholder,
    underline,
    size,
    defaultClass,
    underlineClass
  });
  pop();
}
function Modal($$payload, $$props) {
  const $$slots = sanitize_slots($$props);
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "open",
    "title",
    "size",
    "color",
    "placement",
    "autoclose",
    "outsideclose",
    "dismissable",
    "backdropClass",
    "classBackdrop",
    "dialogClass",
    "classDialog",
    "defaultClass",
    "headerClass",
    "classHeader",
    "bodyClass",
    "classBody",
    "footerClass",
    "classFooter"
  ]);
  push();
  let backdropCls, dialogCls, frameCls, headerCls, bodyCls, footerCls;
  let open = fallback($$props["open"], false);
  let title = fallback($$props["title"], "");
  let size = fallback($$props["size"], "md");
  let color = fallback($$props["color"], "default");
  let placement = fallback($$props["placement"], "center");
  let autoclose = fallback($$props["autoclose"], false);
  let outsideclose = fallback($$props["outsideclose"], false);
  let dismissable = fallback($$props["dismissable"], true);
  let backdropClass = fallback($$props["backdropClass"], "fixed inset-0 z-40 bg-gray-900 bg-black/50 dark:bg-black/80");
  let classBackdrop = fallback($$props["classBackdrop"], () => void 0, true);
  let dialogClass = fallback($$props["dialogClass"], "fixed top-0 start-0 end-0 h-modal md:inset-0 md:h-full z-50 w-full p-4 flex");
  let classDialog = fallback($$props["classDialog"], () => void 0, true);
  let defaultClass = fallback($$props["defaultClass"], "relative flex flex-col mx-auto");
  let headerClass = fallback($$props["headerClass"], "flex justify-between items-center p-4 md:p-5 rounded-t-lg");
  let classHeader = fallback($$props["classHeader"], () => void 0, true);
  let bodyClass = fallback($$props["bodyClass"], "p-4 md:p-5 space-y-4 flex-1 overflow-y-auto overscroll-contain");
  let classBody = fallback($$props["classBody"], () => void 0, true);
  let footerClass = fallback($$props["footerClass"], "flex items-center p-4 md:p-5 space-x-3 rtl:space-x-reverse rounded-b-lg");
  let classFooter = fallback($$props["classFooter"], () => void 0, true);
  const getPlacementClasses = (placement2) => {
    switch (placement2) {
      case "top-left":
        return ["justify-start", "items-start"];
      case "top-center":
        return ["justify-center", "items-start"];
      case "top-right":
        return ["justify-end", "items-start"];
      case "center-left":
        return ["justify-start", "items-center"];
      case "center":
        return ["justify-center", "items-center"];
      case "center-right":
        return ["justify-end", "items-center"];
      case "bottom-left":
        return ["justify-start", "items-end"];
      case "bottom-center":
        return ["justify-center", "items-end"];
      case "bottom-right":
        return ["justify-end", "items-end"];
      default:
        return ["justify-center", "items-center"];
    }
  };
  const sizes = {
    xs: "max-w-md",
    sm: "max-w-lg",
    md: "max-w-2xl",
    lg: "max-w-4xl",
    xl: "max-w-7xl"
  };
  backdropCls = twMerge(backdropClass, classBackdrop);
  dialogCls = twMerge(dialogClass, classDialog, getPlacementClasses(placement));
  frameCls = twMerge(defaultClass, "w-full divide-y", $$sanitized_props.class);
  headerCls = twMerge(headerClass, classHeader);
  bodyCls = twMerge(bodyClass, classBody);
  footerCls = twMerge(footerClass, classFooter);
  if (open) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div${attr_class(clsx(backdropCls))}></div>  <div${attr_class(clsx(dialogCls))} tabindex="-1" aria-modal="true" role="dialog"><div${attr_class(`flex relative ${stringify(sizes[size])} w-full max-h-screen`)}>`;
    Frame($$payload, spread_props([
      { rounded: true, shadow: true },
      $$restProps,
      {
        class: frameCls,
        color,
        children: ($$payload2) => {
          if ($$slots.header || title) {
            $$payload2.out += "<!--[-->";
            Frame($$payload2, {
              class: headerCls,
              color,
              children: ($$payload3) => {
                $$payload3.out += `<!---->`;
                slot($$payload3, $$props, "header", {}, () => {
                  $$payload3.out += `<h3${attr_class(`text-xl font-semibold ${stringify(color === "default" ? "" : "text-gray-900 dark:text-white")} p-0`)}>${escape_html(title)}</h3>`;
                });
                $$payload3.out += `<!----> `;
                if (dismissable) {
                  $$payload3.out += "<!--[-->";
                  CloseButton($$payload3, { name: "Close modal", color });
                } else {
                  $$payload3.out += "<!--[!-->";
                }
                $$payload3.out += `<!--]-->`;
              },
              $$slots: { default: true }
            });
          } else {
            $$payload2.out += "<!--[!-->";
          }
          $$payload2.out += `<!--]--> <div${attr_class(clsx(bodyCls))} role="document">`;
          if (dismissable && !$$slots.header && !title) {
            $$payload2.out += "<!--[-->";
            CloseButton($$payload2, {
              name: "Close modal",
              class: "absolute top-3 end-2.5",
              color
            });
          } else {
            $$payload2.out += "<!--[!-->";
          }
          $$payload2.out += `<!--]--> <!---->`;
          slot($$payload2, $$props, "default", {}, null);
          $$payload2.out += `<!----></div> `;
          if ($$slots.footer) {
            $$payload2.out += "<!--[-->";
            Frame($$payload2, {
              class: footerCls,
              color,
              children: ($$payload3) => {
                $$payload3.out += `<!---->`;
                slot($$payload3, $$props, "footer", {}, null);
                $$payload3.out += `<!---->`;
              },
              $$slots: { default: true }
            });
          } else {
            $$payload2.out += "<!--[!-->";
          }
          $$payload2.out += `<!--]-->`;
        },
        $$slots: { default: true }
      }
    ]));
    $$payload.out += `<!----></div></div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, {
    open,
    title,
    size,
    color,
    placement,
    autoclose,
    outsideclose,
    dismissable,
    backdropClass,
    classBackdrop,
    dialogClass,
    classDialog,
    defaultClass,
    headerClass,
    classHeader,
    bodyClass,
    classBody,
    footerClass,
    classFooter
  });
  pop();
}
const progressInfo = [
  {
    stepCount: 1,
    title: "upgrade prerequisites check",
    log: "still processing",
    error: ""
  },
  {
    stepCount: 2,
    title: "checking if the package version exists",
    log: "still processing",
    error: ""
  },
  {
    stepCount: 3,
    title: "kubernetes version upgrade diff",
    log: "still processing",
    error: ""
  },
  {
    stepCount: 4,
    title: "Kubeadm update",
    log: "still processing",
    error: ""
  },
  // TODO:
  //  optional step
  {
    stepCount: 5,
    title: "Cluster Upgrade Plan",
    log: "still processing",
    error: ""
  },
  {
    stepCount: 6,
    title: "Kubernetes Cluster Upgrade",
    log: "still processing",
    error: ""
  },
  {
    stepCount: 7,
    title: "Kubelet update",
    log: "still processing",
    error: ""
  },
  {
    stepCount: 8,
    title: "Restarting Kubelet",
    log: "still processing",
    error: ""
  },
  {
    stepCount: 9,
    title: "Kubectl update",
    log: "still processing",
    error: ""
  }
];
function Step($$payload, $$props) {
  push();
  let {
    items = [
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false,
      false
    ]
  } = $$props;
  Accordion($$payload, {
    activeClass: "bg-blue-100 dark:bg-gray-800 text-blue-600 dark:text-white focus:ring-4 focus:ring-blue-200 dark:focus:ring-blue-800",
    inactiveClass: "text-gray-500 dark:text-gray-400 hover:bg-blue-100 dark:hover:bg-gray-800",
    children: ($$payload2) => {
      const each_array = ensure_array_like(progressInfo);
      $$payload2.out += `<!--[-->`;
      for (let i = 0, $$length = each_array.length; i < $$length; i++) {
        let step = each_array[i];
        AccordionItem($$payload2, {
          open: items[i],
          children: ($$payload3) => {
            $$payload3.out += `<p class="mb-2 text-gray-500 dark:text-gray-400">${escape_html(step.log)}</p>`;
          },
          $$slots: {
            default: true,
            header: ($$payload3) => {
              $$payload3.out += `<span slot="header">${escape_html(step.title)}</span>`;
            }
          }
        });
      }
      $$payload2.out += `<!--]-->`;
    },
    $$slots: { default: true }
  });
  bind_props($$props, { items });
  pop();
}
function Nodes($$payload, $$props) {
  push();
  let { nodes, remove } = $$props;
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    const each_array = ensure_array_like(nodes);
    $$payload2.out += `<ul class="nodes"><!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let node = each_array[$$index];
      $$payload2.out += `<li${attr_class(clsx({ done: node.done }))}><label class="svelte-s7giym">`;
      Button($$payload2, {
        type: "text",
        get checked() {
          return node.done;
        },
        set checked($$value) {
          node.done = $$value;
          $$settled = false;
        },
        children: ($$payload3) => {
          $$payload3.out += `<span class="svelte-s7giym">${escape_html(node.name)}</span>`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> <button aria-label="Remove" class="svelte-s7giym"></button></label></li>`;
    }
    $$payload2.out += `<!--]--></ul>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
function _page($$payload, $$props) {
  push();
  let drainNodes = false;
  let certificateRenewal = false;
  let promptOnError = true;
  let selected = /* @__PURE__ */ new Map();
  let packagesInfo = [];
  let formModal = false;
  let scrollingModal = false;
  let finalizerModal = false;
  let logForScrollingModal = "";
  let errorForScrollingModal = "";
  let selectedVersion;
  let toggleAccordion = [
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false,
    false
  ];
  let nodes = [];
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="action svelte-1vmp9ii"><div class="button-group svelte-1vmp9ii">`;
    ButtonGroup($$payload2, {
      children: ($$payload3) => {
        Button($$payload3, {
          outline: true,
          color: "red",
          children: ($$payload4) => {
            $$payload4.out += `<!---->upgrade`;
          },
          $$slots: { default: true }
        });
      },
      $$slots: { default: true }
    });
    $$payload2.out += `<!----></div></div> <div class="processing svelte-1vmp9ii"><div class="nodes svelte-1vmp9ii"><div class="nodeList"><h2 class="text-black dark:text-white svelte-1vmp9ii">nodes to be upgraded</h2> `;
    Nodes($$payload2, { nodes: nodes.filter((t) => !t.done) });
    $$payload2.out += `<!----></div> <div class="done"><h2 class="text-black dark:text-white svelte-1vmp9ii">upgraded nodes</h2> `;
    Nodes($$payload2, { nodes: nodes.filter((t) => t.done) });
    $$payload2.out += `<!----></div></div> <div class="nodes svelte-1vmp9ii">`;
    Step($$payload2, { toggleAccordion });
    $$payload2.out += `<!----></div></div> `;
    Modal($$payload2, {
      size: "xs",
      autoclose: false,
      class: "w-full",
      get open() {
        return formModal;
      },
      set open($$value) {
        formModal = $$value;
        $$settled = false;
      },
      children: ($$payload3) => {
        Label($$payload3, {
          children: ($$payload4) => {
            const each_array = ensure_array_like(packagesInfo);
            $$payload4.out += `<!---->Select K8s version for each OS <h3 class="mb-4 text-xl font-medium text-gray-900 dark:text-white">Select K8s version for Different OS Image</h3> <!--[-->`;
            for (let i = 0, $$length = each_array.length; i < $$length; i++) {
              let packageInfo = each_array[i];
              $$payload4.out += `<p>${escape_html(packageInfo.distroPrettyName)}</p> `;
              Select($$payload4, {
                class: "mt-2",
                items: packageInfo.availableVersions.filter((v) => v).map((value) => ({ value, name: value })),
                onchange: () => selected.set(packageInfo.distroPrettyName, selectedVersion),
                get value() {
                  return selectedVersion;
                },
                set value($$value) {
                  selectedVersion = $$value;
                  $$settled = false;
                }
              });
              $$payload4.out += `<!---->`;
            }
            $$payload4.out += `<!--]-->`;
          },
          $$slots: { default: true }
        });
        $$payload3.out += `<!----> <div class="flex items-start">`;
        Checkbox($$payload3, {
          get checked() {
            return certificateRenewal;
          },
          set checked($$value) {
            certificateRenewal = $$value;
            $$settled = false;
          },
          children: ($$payload4) => {
            $$payload4.out += `<!---->Certificate Renewal`;
          },
          $$slots: { default: true }
        });
        $$payload3.out += `<!----></div> <div class="flex items-start">`;
        Checkbox($$payload3, {
          get checked() {
            return drainNodes;
          },
          set checked($$value) {
            drainNodes = $$value;
            $$settled = false;
          },
          children: ($$payload4) => {
            $$payload4.out += `<!---->Node Draining before Upgrade`;
          },
          $$slots: { default: true }
        });
        $$payload3.out += `<!----></div> <div class="flex items-start">`;
        Checkbox($$payload3, {
          get checked() {
            return promptOnError;
          },
          set checked($$value) {
            promptOnError = $$value;
            $$settled = false;
          },
          children: ($$payload4) => {
            $$payload4.out += `<!---->Only Prompt on Error`;
          },
          $$slots: { default: true }
        });
        $$payload3.out += `<!----></div> `;
        Button($$payload3, {
          type: "submit",
          class: "w-full1",
          children: ($$payload4) => {
            $$payload4.out += `<!---->Submit`;
          },
          $$slots: { default: true }
        });
        $$payload3.out += `<!---->`;
      },
      $$slots: { default: true }
    });
    $$payload2.out += `<!----> `;
    Modal($$payload2, {
      title: "Prompt on error catch",
      get open() {
        return scrollingModal;
      },
      set open($$value) {
        scrollingModal = $$value;
        $$settled = false;
      },
      children: ($$payload3) => {
        $$payload3.out += `<p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">${escape_html(errorForScrollingModal)}</p> <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">${escape_html(logForScrollingModal)}</p>`;
      },
      $$slots: {
        default: true,
        footer: ($$payload3) => {
          {
            ButtonGroup($$payload3, {
              children: ($$payload4) => {
                Button($$payload4, {
                  pill: true,
                  color: "red",
                  children: ($$payload5) => {
                    $$payload5.out += `<!---->retry current step`;
                  },
                  $$slots: { default: true }
                });
                $$payload4.out += `<!----> `;
                Button($$payload4, {
                  pill: true,
                  color: "green",
                  children: ($$payload5) => {
                    $$payload5.out += `<!---->skip current node`;
                  },
                  $$slots: { default: true }
                });
                $$payload4.out += `<!----> `;
                Button($$payload4, {
                  pill: true,
                  color: "yellow",
                  children: ($$payload5) => {
                    $$payload5.out += `<!---->proceed next step`;
                  },
                  $$slots: { default: true }
                });
                $$payload4.out += `<!---->`;
              },
              $$slots: { default: true }
            });
          }
        }
      }
    });
    $$payload2.out += `<!----> `;
    Modal($$payload2, {
      title: "Minor Upgrade Successful",
      color: "green",
      autoclose: true,
      get open() {
        return finalizerModal;
      },
      set open($$value) {
        finalizerModal = $$value;
        $$settled = false;
      },
      children: ($$payload3) => {
        $$payload3.out += `<div class="text-base leading-relaxed">Upgrade Report:</div>`;
      },
      $$slots: {
        default: true,
        footer: ($$payload3) => {
          {
            Button($$payload3, {
              color: "green",
              children: ($$payload4) => {
                $$payload4.out += `<!---->Homepage`;
              },
              $$slots: { default: true }
            });
            $$payload3.out += `<!----> `;
            Button($$payload3, {
              color: "alternative",
              children: ($$payload4) => {
                $$payload4.out += `<!---->Okay`;
              },
              $$slots: { default: true }
            });
            $$payload3.out += `<!---->`;
          }
        }
      }
    });
    $$payload2.out += `<!---->`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
export {
  _page as default
};
