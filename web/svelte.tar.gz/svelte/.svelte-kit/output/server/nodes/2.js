

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/minor-upgrade/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.BtbTxLWN.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/DUIfCcmH.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/B5Xqpwiy.js","_app/immutable/chunks/e6tFiNcK.js"];
export const stylesheets = [];
export const fonts = [];
