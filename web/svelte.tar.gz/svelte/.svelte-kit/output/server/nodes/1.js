

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.C0gk142D.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/DUIfCcmH.js","_app/immutable/chunks/DmpyFbEB.js","_app/immutable/chunks/B5Xqpwiy.js","_app/immutable/chunks/DuSRoghO.js","_app/immutable/chunks/C7gX1wh4.js","_app/immutable/chunks/COfwV3k6.js","_app/immutable/chunks/DV0nxC6P.js"];
export const stylesheets = [];
export const fonts = [];
