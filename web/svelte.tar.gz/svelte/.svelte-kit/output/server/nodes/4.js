

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/minor-upgrade/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.izO6snTb.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/DUIfCcmH.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/DmpyFbEB.js","_app/immutable/chunks/B5Xqpwiy.js","_app/immutable/chunks/CbI-yysI.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DV0nxC6P.js","_app/immutable/chunks/BsmY1r07.js","_app/immutable/chunks/DuSRoghO.js"];
export const stylesheets = ["_app/immutable/assets/4.CbjNhOYI.css"];
export const fonts = [];
