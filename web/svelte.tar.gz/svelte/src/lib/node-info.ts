// nodeInfo struct
