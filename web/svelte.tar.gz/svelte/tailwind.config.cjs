const config = {
	darkMode: 'class'
	// ...
};
